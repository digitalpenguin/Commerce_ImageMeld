<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Image Meld for Commerce on MODX
==

**Enables customers to meld/merge images to create custom designs when purchasing products.**

** *Thanks to **nopixel** for sponsoring the development of this module.*

This module takes advantage of the Fabric.js javascript canvas library http://fabricjs.com/

The snippet is designed to be used on a product detail page, where the editing canvas will be presented
with a template image selected by you, the developer (or shop owner). The template image acts
as an overlay with transparent sections where the image can be customised. Think of an item such as
sunglasses frames, a watch band, or a badge.

The customer uploads the image/pattern which appears behind the overlaid image template, and they
can then use the controls to zoom, rotate and move the image until they\'re happy with the positioning.
When the product is added to the cart, both the original source image provided by the customer, and
the newly created melded images are uploaded to the server and added to the customer\'s order.

When viewing the order in the manager, thumbnails of both images are shown on each product with options
to download directly or open the full-sized image in a new window.


Requirements
-

- MODX CMS 2.6.5 +

  https://modx.com/download


- Commerce for MODX 1.2 +

  https://modmore.com/commerce/


- PHP 7.1 +


Installation
-

Install via the MODX package manager.

Setup
-
1. **System Settings:** Set the `commerce_imagemeld.melds_path` and `commerce_imagemeld.melds_url` to
your preferred location or leave as the default.

2. Create a product detail page with the add to cart form that you want to use.

2. Add the `Commerce_ImageMeld` snippet at the top of your page template.
In addition to the `&productId` parameter, the snippet requires an `&image` parameter for the
   overlaid image template you want to use. You could use the `[[++assets_url]]` system setting
   along with the path to your image. Or, you could use a TV.

**This must be a PNG image.**

Example:

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[++assets_url]]uploads/template.png`
]]
```

or

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[*my_template_var]]`
]]
```

4. Add the placeholders to your HTML markup. The output is split into multiple placeholders to be
as flexible as possible. You can even modify them and add your own (see snippet section below).

- `[[+cim.product_id]]` - outputs the product id
- `[[+cim.canvas]]` - this is the editing canvas _(place anywhere)_
- `[[+cim.file_input]]` - this is the upload button customers use to add their image _(place anywhere)_
- `[[+cim.controls]]` - zoom, rotate, move and save buttons _(place anywhere)_
- `[[+cim.default_css]]` - this css shows the required size values for the canvas elements. Either use this
  or add the same CSS rules to your stylesheet _(place in some `<style></style>` tags)_
- `[[+cim.preview]]` - this is where the final image is shown after clicking save. _(A good place for this might
  be a modal window that shows on save along with the add to cart form/button, but it can be placed anywhere)_
- `[[+cim.hidden_inputs]]` - this holds all the values needed to be submitted along with the add to cart form.
  **(must be placed inside the `<form></form>` tags.)**

5. Success!


Snippet Parameters
-

This module has a single snippet `[[Commerce_ImageMeld]]`.
It should be added to the top of your MODX page template. The snippet doesn\'t return anything itself, all output is via placeholders.

There are 8 parameters available in total. Only two are required.

**Required**
- `&productId`: **REQUIRED** The product id of the ImageMeld product.
- `&image`: **REQUIRED** as shown above, the value should be the image URL.

**Advanced**
- `&includeJS`: Default is `1`. Set this to `0` if you want to ignore the default JavaScript and
write your own.

**Custom Template Chunks**
- `&tplCanvas`: value should be the name of a custom canvas chunk.
- `&tplFileInput`: value should be the name of a custom file input chunk.
- `&tplHiddenInputs`: value should be the name of a custom hidden inputs chunk.
- `&tplControls`: value should be the name of a custom controls chunk.
- `&tplPreview`: value should be the name of a custom preview chunk.

',
    'changelog' => 'Commerce_ImageMeld for Commerce 1.0.0-beta
---------------------------------
Released on 21/1/2021

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c724020e23bf5532552bd1274f79ab19',
      'native_key' => 'commerce_imagemeld',
      'filename' => 'modNamespace/d0c2e15030606c6820715aa2b5eb5790.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5503cd6394171528de22df407abf6ebb',
      'native_key' => '5503cd6394171528de22df407abf6ebb',
      'filename' => 'xPDOFileVehicle/2154550406dbabe41c02f02d58d1ffac.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a56c58e3d7db5d32cabeac54a52a9562',
      'native_key' => 'a56c58e3d7db5d32cabeac54a52a9562',
      'filename' => 'xPDOFileVehicle/982041d10d840f850ea8efc41d1fad45.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77258b3ba940ef6cb56e53af3c9fa1ac',
      'native_key' => 'commerce_imagemeld.melds_path',
      'filename' => 'modSystemSetting/6a2bced12716cc91b23c91b77863e5e5.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0109a1eaabc0ef1f5b502741037a6b9',
      'native_key' => 'commerce_imagemeld.melds_url',
      'filename' => 'modSystemSetting/2013a4572f50a380177df5b7ff055548.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b2ae90d4c91d04311471e1c71e879409',
      'native_key' => NULL,
      'filename' => 'modCategory/7c699fe6d398c9a606aa08055fe64f1f.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
  ),
);