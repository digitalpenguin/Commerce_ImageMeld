<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Image Meld for Commerce on MODX
==

**Enables customers to meld/merge images to create custom designs when purchasing products.**

** *Thanks to **nopixel** for sponsoring the development of this module.*

This module takes advantage of the Fabric.js javascript canvas library http://fabricjs.com/

The snippet is designed to be used on a product detail page, where the editing canvas will be presented
with a template image selected by you, the developer (or shop owner). The template image acts
as an overlay with transparent sections where the image can be customised. Think of an item such as
sunglasses frames, a watch band, or a badge.

The customer uploads the image/pattern which appears behind the overlaid image template, and they
can then use the controls to zoom, rotate and move the image until they\'re happy with the positioning.
When the product is added to the cart, both the original source image provided by the customer, and
the newly created melded images are uploaded to the server and added to the customer\'s order.

When viewing the order in the manager, thumbnails of both images are shown on each product with options
to download directly or open the full-sized image in a new window.


Requirements
-

- MODX CMS 2.6.5 +

  https://modx.com/download


- Commerce for MODX 1.2 +

  https://modmore.com/commerce/


- PHP 7.1 +


Installation
-

Install via the MODX package manager.

Setup
-
1. **System Settings:** Set the `commerce_imagemeld.melds_path` and `commerce_imagemeld.melds_url` to
your preferred location or leave as the default.

2. Create a product detail page with the add to cart form that you want to use.

2. Add the `Commerce_ImageMeld` snippet at the top of your page template.
In addition to the `&productId` parameter, the snippet requires an `&image` parameter for the
   overlaid image template you want to use. You could use the `[[++assets_url]]` system setting
   along with the path to your image. Or, you could use a TV.

**This must be a PNG image.**

Example:

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[++assets_url]]uploads/template.png`
]]
```

or

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[*my_template_var]]`
]]
```

4. Add the placeholders to your HTML markup. The output is split into multiple placeholders to be
as flexible as possible. You can even modify them and add your own (see snippet section below).

- `[[+cim.product_id]]` - outputs the product id
- `[[+cim.canvas]]` - this is the editing canvas _(place anywhere)_
- `[[+cim.file_input]]` - this is the upload button customers use to add their image _(place anywhere)_
- `[[+cim.controls]]` - zoom, rotate, move and save buttons _(place anywhere)_
- `[[+cim.default_css]]` - this css shows the required size values for the canvas elements. Either use this
  or add the same CSS rules to your stylesheet _(place in some `<style></style>` tags)_
- `[[+cim.preview]]` - this is where the final image is shown after clicking save. _(A good place for this might
  be a modal window that shows on save along with the add to cart form/button, but it can be placed anywhere)_
- `[[+cim.hidden_inputs]]` - this holds all the values needed to be submitted along with the add to cart form.
  **(must be placed inside the `<form></form>` tags.)**

5. Success!


Snippet Parameters
-

This module has a single snippet `[[Commerce_ImageMeld]]`.
It should be added to the top of your MODX page template. The snippet doesn\'t return anything itself, all output is via placeholders.

There are 8 parameters available in total. Only two are required.

**Required**
- `&productId`: **REQUIRED** The product id of the ImageMeld product.
- `&image`: **REQUIRED** as shown above, the value should be the image URL.

**Advanced**
- `&includeJS`: Default is `1`. Set this to `0` if you want to ignore the default JavaScript and
write your own.

**Custom Template Chunks**
- `&tplCanvas`: value should be the name of a custom canvas chunk.
- `&tplFileInput`: value should be the name of a custom file input chunk.
- `&tplHiddenInputs`: value should be the name of a custom hidden inputs chunk.
- `&tplControls`: value should be the name of a custom controls chunk.
- `&tplPreview`: value should be the name of a custom preview chunk.

',
    'changelog' => 'Commerce_ImageMeld for Commerce 1.0.0-beta2
---------------------------------
Released on 2/2/2021

- Added system settings for min width and min height.
- Added error_msg placeholder
- Added JS and PHP detection of image size

Commerce_ImageMeld for Commerce 1.0.0-beta
---------------------------------
Released on 21/1/2021

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '186a1c36f99703be2b5e4feccd3898d8',
      'native_key' => 'commerce_imagemeld',
      'filename' => 'modNamespace/3314da932fe1d73f9d281009a09a2618.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7fc79a78cc946160876e0b64f087cb91',
      'native_key' => '7fc79a78cc946160876e0b64f087cb91',
      'filename' => 'xPDOFileVehicle/97fd6da9b6b2dbd8d73a600d8d274b63.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7a4d7501d092cd464a7833118bf3edb0',
      'native_key' => '7a4d7501d092cd464a7833118bf3edb0',
      'filename' => 'xPDOFileVehicle/11d24cb0909652144be3d9274425477c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a51553e1388b36b31d1b6f585f02a2c',
      'native_key' => 'commerce_imagemeld.assets_path',
      'filename' => 'modSystemSetting/a8c3968777050df0df30035f7a0a1467.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79d2371dc2854d5fe8eef3d2e3b47f85',
      'native_key' => 'commerce_imagemeld.assets_url',
      'filename' => 'modSystemSetting/92be46131e70baf5f2106a2b27ac4e99.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9de722d8eddb06e4cab6e39258888775',
      'native_key' => 'commerce_imagemeld.core_path',
      'filename' => 'modSystemSetting/66ae67cb6685f1799f7278bc01a143eb.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27b2046cc6beb6c15bcd680ba3555f0a',
      'native_key' => 'commerce_imagemeld.melds_path',
      'filename' => 'modSystemSetting/091229e47364107b893371957ea4d7cf.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c166c29af80131e0a72424d0565590a',
      'native_key' => 'commerce_imagemeld.melds_url',
      'filename' => 'modSystemSetting/daeb0d8fcfe0e4d0311a135de543d3c7.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ccb7f983b4dfbbf218fcfe6fca608af',
      'native_key' => 'commerce_imagemeld.min_width',
      'filename' => 'modSystemSetting/f95fd8fad08fef9c6fd2ccabfdc81c6f.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '957abc4e48ef0acc209bf6df5d1301af',
      'native_key' => 'commerce_imagemeld.min_height',
      'filename' => 'modSystemSetting/e635e43c594765a8aeafd383e8fe69c3.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6e6166b707bc216930f72f5701e0f941',
      'native_key' => NULL,
      'filename' => 'modCategory/37a82f649a0730cad82fd524e72bbf6d.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
  ),
);