<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Image Meld for Commerce on MODX
==

**Enables customers to meld/merge images to create custom designs when purchasing products.**

** *Thanks to **nopixel** for sponsoring the development of this module.*

This module takes advantage of the Fabric.js javascript canvas library http://fabricjs.com/

The snippet is designed to be used on a product detail page, where the editing canvas will be presented
with a template image selected by you, the developer (or shop owner). The template image acts
as an overlay with transparent sections where the image can be customised. Think of an item such as
sunglasses frames, a watch band, or a badge.

The customer uploads the image/pattern which appears behind the overlaid image template, and they
can then use the controls to zoom, rotate and move the image until they\'re happy with the positioning.
When the product is added to the cart, both the original source image provided by the customer, and
the newly created melded images are uploaded to the server and added to the customer\'s order.

When viewing the order in the manager, thumbnails of both images are shown on each product with options
to download directly or open the full-sized image in a new window.


Requirements
-

- MODX CMS 2.6.5 +

  https://modx.com/download


- Commerce for MODX 1.2 +

  https://modmore.com/commerce/


- PHP 7.1 +


Installation
-

Install via the MODX package manager.

Setup
-
1. **System Settings:** Set the `commerce_imagemeld.melds_path` and `commerce_imagemeld.melds_url` to
your preferred location or leave as the default.

2. Create a product detail page with the add to cart form that you want to use.

2. Add the `Commerce_ImageMeld` snippet at the top of your page template.
In addition to the `&productId` parameter, the snippet requires an `&image` parameter for the
   overlaid image template you want to use. You could use the `[[++assets_url]]` system setting
   along with the path to your image. Or, you could use a TV.

**This must be a PNG image.**

Example:

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[++assets_url]]uploads/template.png`
]]
```

or

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[*my_template_var]]`
]]
```

4. Add the placeholders to your HTML markup. The output is split into multiple placeholders to be
as flexible as possible. You can even modify them and add your own (see snippet section below).

- `[[+cim.product_id]]` - outputs the product id
- `[[+cim.canvas]]` - this is the editing canvas _(place anywhere)_
- `[[+cim.file_input]]` - this is the upload button customers use to add their image _(place anywhere)_
- `[[+cim.controls]]` - zoom, rotate, move and save buttons _(place anywhere)_
- `[[+cim.default_css]]` - this css shows the required size values for the canvas elements. Either use this
  or add the same CSS rules to your stylesheet _(place in some `<style></style>` tags)_
- `[[+cim.preview]]` - this is where the final image is shown after clicking save. _(A good place for this might
  be a modal window that shows on save along with the add to cart form/button, but it can be placed anywhere)_
- `[[+cim.hidden_inputs]]` - this holds all the values needed to be submitted along with the add to cart form.
  **(must be placed inside the `<form></form>` tags.)**

5. Success!


Snippet Parameters
-

This module has a single snippet `[[Commerce_ImageMeld]]`.
It should be added to the top of your MODX page template. The snippet doesn\'t return anything itself, all output is via placeholders.

There are 8 parameters available in total. Only two are required.

**Required**
- `&productId`: **REQUIRED** The product id of the ImageMeld product.
- `&image`: **REQUIRED** as shown above, the value should be the image URL.

**Advanced**
- `&includeJS`: Default is `1`. Set this to `0` if you want to ignore the default JavaScript and
write your own.

**Custom Template Chunks**
- `&tplCanvas`: value should be the name of a custom canvas chunk.
- `&tplFileInput`: value should be the name of a custom file input chunk.
- `&tplHiddenInputs`: value should be the name of a custom hidden inputs chunk.
- `&tplControls`: value should be the name of a custom controls chunk.
- `&tplPreview`: value should be the name of a custom preview chunk.

',
    'changelog' => 'Commerce_ImageMeld for Commerce 1.0.0-beta3
---------------------------------
Released on 3/2/2021

- Snippet now returns core product values as placeholders

Commerce_ImageMeld for Commerce 1.0.0-beta2
---------------------------------
Released on 2/2/2021

- Added system settings for min width and min height.
- Added error_msg placeholder
- Added JS and PHP detection of image size

Commerce_ImageMeld for Commerce 1.0.0-beta
---------------------------------
Released on 21/1/2021

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '727fe6af34ef9add406aa707b1fe2d98',
      'native_key' => 'commerce_imagemeld',
      'filename' => 'modNamespace/75e229a30d93bd1ab90a4b2b0785eeb2.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '36f8b982a99af675984543c1d01b6247',
      'native_key' => '36f8b982a99af675984543c1d01b6247',
      'filename' => 'xPDOFileVehicle/f1b74dbc7269479ca1e32eb080908f68.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'da5f8be5f447b1623a6d7bfacef83cc6',
      'native_key' => 'da5f8be5f447b1623a6d7bfacef83cc6',
      'filename' => 'xPDOFileVehicle/f6555c999e92269bb8a080e3e1526f94.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dee1fcc1a2b0afd607148244a05dcd70',
      'native_key' => 'commerce_imagemeld.assets_path',
      'filename' => 'modSystemSetting/0ed78e1f355ccc577e658d7e2d678c5e.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a79f6a549eb65d0b12d11290c719173d',
      'native_key' => 'commerce_imagemeld.assets_url',
      'filename' => 'modSystemSetting/76affa18ff69c10fea476af451a113a3.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa0c872184080c885e0cd50e781e7d59',
      'native_key' => 'commerce_imagemeld.core_path',
      'filename' => 'modSystemSetting/874151a598ea8807623e119b16d24fa0.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f20480521a80c420faecf416167075f0',
      'native_key' => 'commerce_imagemeld.melds_path',
      'filename' => 'modSystemSetting/d9307a296f2ce7ce02d5b59d0a68585c.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b4870736134d64b2ac78299a92115d',
      'native_key' => 'commerce_imagemeld.melds_url',
      'filename' => 'modSystemSetting/b3ceb04fc0a8e0277dd5e2e61a1c4b4a.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3a12243471ef09b7eed37ae01f97724',
      'native_key' => 'commerce_imagemeld.min_width',
      'filename' => 'modSystemSetting/d94f76ac221814374dea718a08c46411.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '398edd78c802ce7e31f8c81ef900f4d8',
      'native_key' => 'commerce_imagemeld.min_height',
      'filename' => 'modSystemSetting/79fe9850b58ecafce38c974234d738e5.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a3ee52d3ae6e2644d1e7a880cec1ca11',
      'native_key' => NULL,
      'filename' => 'modCategory/d24b0a3db52aa221644dcf88ada82785.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
  ),
);