<?php

$xpdo_meta_map = array (
  'xpdoSimpleObject' => 
  array (
    0 => 'cimMeld',
  ),
);