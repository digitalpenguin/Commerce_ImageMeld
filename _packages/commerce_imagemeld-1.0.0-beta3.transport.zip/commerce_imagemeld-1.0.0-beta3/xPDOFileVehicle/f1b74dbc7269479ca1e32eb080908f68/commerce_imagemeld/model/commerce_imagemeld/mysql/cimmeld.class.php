<?php
require_once strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/cimmeld.class.php';
/**
 * Commerce_ImageMeld for Commerce.
 *
 * Copyright 2020 by Murray Wood <hello@digitalpenguin.hk>
 *
 * This file is meant to be used with Commerce by modmore. A valid Commerce license is required.
 *
 * @package commerce_imagemeld
 * @license See core/components/commerce_imagemeld/docs/license.txt
 */
class cimMeld_mysql extends cimMeld
{

}
