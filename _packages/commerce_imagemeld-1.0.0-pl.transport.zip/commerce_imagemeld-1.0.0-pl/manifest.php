<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Image Meld for Commerce on MODX
==

**Enables customers to meld/merge images to create custom designs when purchasing products.**

** *Thanks to **nopixel** for sponsoring the development of this module.*

This module takes advantage of the Fabric.js javascript canvas library http://fabricjs.com/

The snippet is designed to be used on a product detail page, where the editing canvas will be presented
with a template image selected by you, the developer (or shop owner). The template image acts
as an overlay with transparent sections where the image can be customised. Think of an item such as
sunglasses frames, a watch band, or a badge.

The customer uploads the image/pattern which appears behind the overlaid image template, and they
can then use the controls to zoom, rotate and move the image until they\'re happy with the positioning.
When the product is added to the cart, both the original source image provided by the customer, and
the newly created melded images are uploaded to the server and added to the customer\'s order.

When viewing the order in the manager, thumbnails of both images are shown on each product with options
to download directly or open the full-sized image in a new window.


Requirements
-

- MODX CMS 2.6.5 +

  https://modx.com/download


- Commerce for MODX 1.2 +

  https://modmore.com/commerce/


- PHP 7.1 +


Installation
-

Install via the MODX package manager.

Setup
-
1. **System Settings:** Set the `commerce_imagemeld.melds_path` and `commerce_imagemeld.melds_url` to
your preferred location or leave as the default.

2. Create a product detail page with the add to cart form that you want to use.

2. Add the `Commerce_ImageMeld` snippet at the top of your page template.
In addition to the `&productId` parameter, the snippet requires an `&image` parameter for the
   overlaid image template you want to use. You could use the `[[++assets_url]]` system setting
   along with the path to your image. Or, you could use a TV.

**This must be a PNG image.**

Example:

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[++assets_url]]uploads/template.png`
]]
```

or

```
[[Commerce_ImageMeld?
    &productId=`10`
    &image=`[[*my_template_var]]`
]]
```

4. Add the placeholders to your HTML markup. The output is split into multiple placeholders to be
as flexible as possible. You can even modify them and add your own (see snippet section below).

- `[[+cim.product_id]]` - outputs the product id
- `[[+cim.canvas]]` - this is the editing canvas _(place anywhere)_
- `[[+cim.file_input]]` - this is the upload button customers use to add their image _(place anywhere)_
- `[[+cim.controls]]` - zoom, rotate, move and save buttons _(place anywhere)_
- `[[+cim.default_css]]` - this css shows the required size values for the canvas elements. Either use this
  or add the same CSS rules to your stylesheet _(place in some `<style></style>` tags)_
- `[[+cim.preview]]` - this is where the final image is shown after clicking save. _(A good place for this might
  be a modal window that shows on save along with the add to cart form/button, but it can be placed anywhere)_
- `[[+cim.hidden_inputs]]` - this holds all the values needed to be submitted along with the add to cart form.
  **(must be placed inside the `<form></form>` tags.)**

5. Success!


Snippet Parameters
-

This module has a single snippet `[[Commerce_ImageMeld]]`.
It should be added to the top of your MODX page template. The snippet doesn\'t return anything itself, all output is via placeholders.

There are 8 parameters available in total. Only two are required.

**Required**
- `&productId`: **REQUIRED** The product id of the ImageMeld product.
- `&image`: **REQUIRED** as shown above, the value should be the image URL.

**Advanced**
- `&includeJS`: Default is `1`. Set this to `0` if you want to ignore the default JavaScript and
write your own.

**Custom Template Chunks**
- `&tplCanvas`: value should be the name of a custom canvas chunk.
- `&tplFileInput`: value should be the name of a custom file input chunk.
- `&tplHiddenInputs`: value should be the name of a custom hidden inputs chunk.
- `&tplControls`: value should be the name of a custom controls chunk.
- `&tplPreview`: value should be the name of a custom preview chunk.

',
    'changelog' => 'Commerce_ImageMeld for Commerce 1.0.0-pl
---------------------------------
Released on 3/2/2021

- Out of beta!
- Added French lexicon


Commerce_ImageMeld for Commerce 1.0.0-beta3
---------------------------------
Released on 3/2/2021

- Snippet now returns core product values as placeholders


Commerce_ImageMeld for Commerce 1.0.0-beta2
---------------------------------
Released on 2/2/2021

- Added system settings for min width and min height.
- Added error_msg placeholder
- Added JS and PHP detection of image size


Commerce_ImageMeld for Commerce 1.0.0-beta
---------------------------------
Released on 21/1/2021

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cb509d3729d8ee27aa05b250a2ef15f4',
      'native_key' => 'commerce_imagemeld',
      'filename' => 'modNamespace/2f508d75e4a31438e92ba94a8d6167b3.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9af6c244307bfd190e39faf3c4a91faf',
      'native_key' => '9af6c244307bfd190e39faf3c4a91faf',
      'filename' => 'xPDOFileVehicle/8e8e8659bcf5030b40a7056dac8cd20c.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '26413b114c51f27ac9c14239c738c384',
      'native_key' => '26413b114c51f27ac9c14239c738c384',
      'filename' => 'xPDOFileVehicle/ffa17870a1d59550b92f0038fe3382cf.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f11d356693e5bcbd96d33064e68dcc1c',
      'native_key' => 'commerce_imagemeld.assets_path',
      'filename' => 'modSystemSetting/652d89ed9063315351a0ea98723322cd.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce6c3161c4d6293b96926c5bbba5a5c4',
      'native_key' => 'commerce_imagemeld.assets_url',
      'filename' => 'modSystemSetting/e6680ac4ac19d38e4a32394a8319310d.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35ef7cb1a688eda08cc10610d97eb711',
      'native_key' => 'commerce_imagemeld.core_path',
      'filename' => 'modSystemSetting/4ed14105bc1da062c5d4900b4edf3cbd.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '618260ca18d2570348067a1f882bc19a',
      'native_key' => 'commerce_imagemeld.melds_path',
      'filename' => 'modSystemSetting/4bce354070df23ffe080a0ca586bc7aa.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f0e538b07662ed917488282b072db8f',
      'native_key' => 'commerce_imagemeld.melds_url',
      'filename' => 'modSystemSetting/75cf7909cb1fdf71127e63d0f9564447.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '842535abbecefd571eba0ef9b27b7122',
      'native_key' => 'commerce_imagemeld.min_width',
      'filename' => 'modSystemSetting/60e6b1ed488a46d873ed1b1fa364efff.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc853534af33ca005eedbc4610872551',
      'native_key' => 'commerce_imagemeld.min_height',
      'filename' => 'modSystemSetting/ab41a9ec7d968e3972f1f923c3e9723c.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '64a7053972e4326b4e75f3ccab747f04',
      'native_key' => NULL,
      'filename' => 'modCategory/abfef94b18a71a1b6b383422d6fbe220.vehicle',
      'namespace' => 'commerce_imagemeld',
    ),
  ),
);